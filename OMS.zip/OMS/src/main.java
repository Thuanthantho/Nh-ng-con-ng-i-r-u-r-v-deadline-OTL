import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;

public class main {
    public static void main(String[] args){
        System.out.println("*********************************");
        System.out.println("* COSC2081 GROUP ASSIGNMENT     *\n" +
                "* STORE ORDER MANAGEMENT SYSTEM *\n" +
                "* Instructor: Mr. Minh Vu       *\n" +
                "* Group: Group Name             *\n" +
                "* s3751366, Cao Huy Tri         *\n" +
                "* s3911365, Vo Ngoc Diem Tien   *\n" +
                "* s3911999, Nguyen Minh Thuan   *\n" +
                "* s3879343, Quach Nhat Huy      *");
        System.out.println("*********************************\n");

        new Account();


    }


}
